package com.beom.test;

public class Board {
	public static final int LIST_AMOUNT =5;
	public static final int PAGE_LINK_AMOUNT =3;
}
