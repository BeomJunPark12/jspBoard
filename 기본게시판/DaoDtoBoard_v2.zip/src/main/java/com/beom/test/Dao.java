package com.beom.test;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Dao extends Da {
	ResultSet rs = null;

	// 삭제
	public void delete(String no) {
		connect();
		String sql = String.format("delete from %s where b_no=%s", DB.TABLE_PS_BOARD_FREE, no);
		System.out.println("sql: " + sql);
		update(sql);
		close();
	}


	// 글쓰기
	public void write(Dto d) {
		connect();
		String sql = String.format("insert into %s (b_title, b_id, b_text) values('%s', '%s', '%s')"
				, DB.TABLE_PS_BOARD_FREE, d.title, d.id, d.text);
		System.out.println("sql: " + sql);
		update(sql);
		close();
	}
	
	// 글리스트
	public ArrayList<Dto> list(String page) {
		connect();
		
		ArrayList<Dto> posts = new ArrayList<>();
		
		try {
			int startIndex = ((Integer.parseInt(page))-1)*3;
			
			String sql = String.format("select * from %s limit %s,3"
					, DB.TABLE_PS_BOARD_FREE, startIndex);
			System.out.println("sql: " + sql);
			rs = st.executeQuery(sql);
			
			while(rs.next()) {
				posts.add(new Dto(
						rs.getString("B_NO"),
						rs.getString("B_TITLE"),
						rs.getString("B_ID"),
						rs.getString("B_DATETIME"),
						rs.getString("B_HIT"),
						rs.getString("B_TEXT"),
						rs.getString("B_REPLY_COUNT"),
						rs.getString("B_REPLY_ORI")
						));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return posts;
	}
	
	// 글읽기
	public Dto read(String no) {
		connect();
		
		Dto post = null;
		
		try {
			String sql = String.format("select * from %s where b_no=%s", DB.TABLE_PS_BOARD_FREE, no);
			System.out.println("sql: " + sql);
			rs = st.executeQuery(sql);
			rs.next();
			
			post = new Dto(
					rs.getString("B_NO"),
					rs.getString("B_TITLE"),
					rs.getString("B_ID"),
					rs.getString("B_TEXT")
					);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return post;
	}
	
	// 글수정
	public void edit(Dto d, String no) {
		connect();
		
		String sql = String.format("update %s set b_title='%s',b_text='%s' where b_no=%s"
				, DB.TABLE_PS_BOARD_FREE, d.title, d.text, no);
		System.out.println("sql: " + sql);
		update(sql);
		close();
	}
	
	// 전체 글 수 구하기
	public int getPostCount() {
		int count = 0;
		
		connect();
		
		try {
			String sql = String.format("select count(*) from %s"
					, DB.TABLE_PS_BOARD_FREE);
			System.out.println("sql:"+sql);
			rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		close();
		return count;
	}
	
	// 전체 글 수 구하기 <검색>
	public int getSearchPostCount(String word) {
		int count = 0;
		
		connect();
		
		try {
			String sql = String.format("select count(*) from %s where b_title like '%%%s%%'"
					, DB.TABLE_PS_BOARD_FREE, word);
			System.out.println("sql:"+sql);
			rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		close();
		return count;
	}
	
	// 글 리스트 <검색>
	public ArrayList<Dto> listSearch(String word, String page) {
		connect();
		
		ArrayList<Dto> posts = new ArrayList<>();
		
		try {
			int startIndex = ((Integer.parseInt(page))-1)*3;
			
			String sql = String.format("select * from %s where b_title like '%%%s%%' limit %s,3"
					, DB.TABLE_PS_BOARD_FREE, word, startIndex);
			System.out.println("sql:"+sql);
			rs = st.executeQuery(sql);
			
			while (rs.next()) {
				posts.add(new Dto(
						rs.getString("B_NO"),
						rs.getString("B_TITLE"),
						rs.getString("B_ID"),
						rs.getString("B_DATETIME"),
						rs.getString("B_HIT"),
						rs.getString("B_TEXT"),
						rs.getString("B_REPLY_COUNT"),
						rs.getString("B_REPLY_ORI")
						));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		close();
		return posts;
	}
	
	// 총 페이지 수 구하기
	public int getTotalPageCount() {
		int totalPageCount = 0;
		
		int count = getPostCount();	// 만든거 재활용
		
		if (count % 3 == 0) {
			totalPageCount = count / 3;		// case1. 나머지가 없이 딱 떨어지는 경우
		} else {
			totalPageCount = count / 3 + 1;		// case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
		}
		
		return totalPageCount;
	}
	
	// 총 페이지 수 구하기 <검색>
	public int getSearchTotalPageCount(String word) {
		int totalPageCount = 0;
		
		int count = getSearchPostCount(word);
		
		if (count % 3 == 0) {
			totalPageCount = count / 3;		// case1. 나머지가 없이 딱 떨어지는 경우
		} else {
			totalPageCount = count / 3 + 1; 	// case2. 나머지가 있어서 짜투리 페이지가 필요한 경우
		}	
		
		return totalPageCount;
	}
}
	
	

