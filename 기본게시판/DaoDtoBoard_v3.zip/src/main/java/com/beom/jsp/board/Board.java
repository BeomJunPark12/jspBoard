package com.beom.jsp.board;

public class Board {
	public static final int LIST_AMOUNT =5;	// 하나의 리스트에 보일 글 수
	public static final int PAGE_LINK_AMOUNT =3;	// 페이지 링크 한 블럭에 보일 페이지 링크 갯수
	
	// Table 이름
	public static final String TABLE_PS_BOARD_FREE = "PS_BOARD_FREE";	// 자유게시판
}
