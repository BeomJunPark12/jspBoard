package com.beom.jsp.board.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.beom.c.util.Cw;
import com.beom.jsp.board.BoardListProcessor;
import com.beom.jsp.board.dto.Dto;
import com.beom.jsp.board.service.ServiceBoard;

/**
 * Servlet implementation class ControllerBoard

 */
@WebServlet("/board/*")
public class ControllerBoard extends HttpServlet {
	String category;
	String nextPage;
	ServiceBoard service;
    
	@Override
	public void init() throws ServletException {
		service = new ServiceBoard();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		category = request.getParameter("category");
		String action = request.getPathInfo();
		Cw.wn("action:"+action);
		
		if (action!=null) {
			switch(action) {
			case "/del":
				nextPage = "/board/list";
				service.del(category, request.getParameter("no"));
				break;
				
			case "/write":
				nextPage = "/board/list";
				Dto dto = new Dto(
						category,
						request.getParameter("title"),
						request.getParameter("id"),
						request.getParameter("text")
						);
				service.write(dto);
				break;
				
			case "/edit_insert":
				Cw.wn("수정-inserst");
				nextPage = "/edit.jsp";
				request.setAttribute("post", service.read(category, request.getParameter("no")));
				break;
				
			case "/edit_proc":
				Cw.wn("수정-proc");
				nextPage = "/board/list";
				service.edit(
						new Dto(
								request.getParameter("title"),
								request.getParameter("text")
						)
						, request.getParameter("no")
						);
				break;
				
			case "/read":
				nextPage = "/read.jsp";
				Dto d = service.read(category, request.getParameter("no"));
				request.setAttribute("post", d);
				break;
				
			case "/list":
				nextPage = "/list.jsp";
				BoardListProcessor blp = service.list(category, request.getParameter("page"), request.getParameter("word"));
				request.setAttribute("blp", blp);
				break;
			}
			
			RequestDispatcher d = request.getRequestDispatcher(nextPage);
			d.forward(request, response);
		}
	}

	

}
