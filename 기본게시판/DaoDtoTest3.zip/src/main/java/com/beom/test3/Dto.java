package com.beom.test3;

public class Dto {
	public String num;
	public String title;
	public String id;
	public String text;
	public String hit;
	public String datetime;
	public String reply_count;
	public String reply_ori;
	
	

	public Dto(String title, String text) {
		super();
		this.title = title;
		this.text = text;
	}

	public Dto(String num, String title, String id) {
		super();
		this.num = num;
		this.title = title;
		this.id = id;
	}

	public Dto(String num, String title, String id, String text) {
		super();
		this.num = num;
		this.title = title;
		this.id = id;
		this.text = text;
	}
	
	public Dto(String num, String title, String id, String text, String hit, String datetime, String reply_count,
			String reply_ori) {
		super();
		this.num = num;
		this.title = title;
		this.id = id;
		this.text = text;
		this.hit = hit;
		this.datetime = datetime;
		this.reply_count = reply_count;
		this.reply_ori = reply_ori;
	}
	
	
	
}
