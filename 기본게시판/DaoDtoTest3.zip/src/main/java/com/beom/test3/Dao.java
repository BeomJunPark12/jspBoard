package com.beom.test3;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Dao extends Da{
	ResultSet rs;
	
	// 삭제
	public void delete(String num) {
		connect();
		String sql = String.format("delete from %s where num=%s", Db.TABLE_BOARD, num);
		System.out.println("sql: " + sql);
		update(sql);
		close();
	}
	
	// 글쓰기
	public void write(Dto d) {
		connect();
		String sql = String.format("insert into %s (title, id, text) values('%s', '%s', '%s')"
				, Db.TABLE_USER, d.title, d.id, d.text);
		System.out.println("sql: " + sql);
		update(sql);
		close();
	}
	
	// 글리스트
	public ArrayList<Dto> list() {
		connect();
		ArrayList<Dto> posts = new ArrayList<>();
		try {
			String sql = String.format("select * from %s", Db.TABLE_BOARD);
			System.out.println("sql: " + sql);
			rs = st.executeQuery(sql);
			
			while (rs.next()) {
				posts.add(new Dto(
						rs.getString("num"),
						rs.getString("title"),
						rs.getString("id"),
						rs.getString("text"),
						rs.getString("datetime"),
						rs.getString("hit"),
						rs.getString("reply_count"),
						rs.getString("reply_ori")
						));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return posts;
	}
	
	// 글읽기
	public Dto read(String num) {
		Dto post = null;
		connect();
		try {
			String sql = String.format("select * from %s where num=%s", Db.TABLE_BOARD, num);
			System.out.println("sql: " + sql);
			rs = st.executeQuery(sql);
			
			rs.next();
			post = new Dto(
					rs.getString("num"),
					rs.getString("title"),
					rs.getString("id"),
					rs.getString("text")
					);
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return post;
	}
	
	// 글수정
	public void edit(String num,Dto d) {
		connect();
		String sql = String.format("update %s set title='%s', text='%s' where num=%s"
				, Db.TABLE_BOARD, d.title, d.text, num);
		System.out.println("sql: " + sql);
		update(sql);
		close();
	}
	
	
}
